"use strict";

console.log(document.querySelector(".heading"));
console.log(document.querySelector(".heading").textContent);
