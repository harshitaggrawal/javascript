"use strict";
console.log('HEllo this is dom js');

console.log(document.querySelector(".heading"));
console.log(document.querySelector(".heading").textContent);

console.log(document.querySelector(".heading").textContent);


